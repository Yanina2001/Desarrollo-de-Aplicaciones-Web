from django.shortcuts import render
#from practica.models import context
from django.http import HttpResponse
from multiprocessing import context
from django.shortcuts import render
from .models import GeeksModel
from .forms import GeeksForm
from practica.models import datos

# Create your views here.
def nuevoDatoView(request):
    if request.POST:
        nuevo_dato = request.POST.get('Ndato')
        nuevq_descripcion = request.POST.get('Ndescripcion')
        actividades.objects.create(actividad=nueva_actividad, descripcion=nueva_descripcion)
        return redirect(reverse('actividad'))
    return render(request, 'practica/datos.html')

def practicaView(request):
    #return HttpResponse("Hola mundo")
    context = {
        'mensaje':"Hola mundo desde el contexto",
        'actividades':['Investigación',
                        'Practica',
                        'Examen',
                        'calificacion',
        ],
        #'ActividadModelo':actividades.objects.all(),
    }

    return render(request, 'practica/index.html',context)
 
 
def create_view(request):
    context ={}
 
    form = GeeksForm(request.POST or None)
    if form.is_valid():
        form.save()
         
    context['form']= form
    return render(request, "create_view.html", context)

 
def list_view(request):
    context ={}
 
    context["dataset"] = GeeksModel.objects.all()
         
    return render(request, "list_view.html", context)


def detail_view(request, id):
    context ={}
 
    context["data"] = GeeksModel.objects.get(id = id)
         
    return render(request, "detail_view.html", context)


from django.shortcuts import (get_object_or_404,
                              render,
                              HttpResponseRedirect)
 

def detail_view(request, id):
    context ={}
  
    context["data"] = GeeksModel.objects.get(id = id)
          
    return render(request, "detail_view.html", context)
 
def update_view(request, id):
    context ={}
 
    obj = get_object_or_404(GeeksModel, id = id)
 
    form = GeeksForm(request.POST or None, instance = obj)
 
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/"+id)
 
    context["form"] = form
 
    return render(request, "update_view.html", context)


def delete_view(request, id):
    context ={}
 
    obj = get_object_or_404(GeeksModel, id = id)
 
 
    if request.method =="POST":
        obj.delete()
        return HttpResponseRedirect("/")
 
    return render(request, "delete_view.html", context)