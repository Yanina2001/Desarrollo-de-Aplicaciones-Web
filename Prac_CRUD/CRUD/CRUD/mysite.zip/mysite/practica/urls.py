from django.urls import path
from .views import practicaView, nuevoDatoView, detail_view, delete_view

urlpatterns = [path('practica/', practicaView ,name='actividad'),
                path('datos/',nuevoDatoView, name='dato'),
                path('<id>', detail_view ),
                path('<id>/delete', delete_view ),]